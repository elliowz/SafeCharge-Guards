# SafeCharge Guard - installer UI (Magisk / KernelSU / APatch)
# Sourced by the module installer; ui_print and abort are provided by it.
PS=${SC_PS:-/sys/class/power_supply}
DATA=${SC_DATA:-/data/adb/safecharge_guard}
VER=$(grep_prop version "$MODPATH/module.prop" 2>/dev/null)
[ -n "$VER" ] || VER=2.0.0

nap() { sleep 0.2 2>/dev/null; }
rd() { _v=""; [ -r "$1" ] && read -r _v < "$1"; }
bar() { _b=""; _i=0; while [ $_i -lt 10 ]; do [ $_i -lt $1 ] && _b="${_b}█" || _b="${_b}░"; _i=$((_i + 1)); done; printf '%s' "$_b"; }
step() { ui_print ""; ui_print "  $(bar $(($1 * 2))) $2"; nap; }
ok() { ui_print "   ✔ $*"; nap; }
no() { ui_print "   ✘ $*"; nap; }
info() { ui_print "   • $*"; }
first() { for _f in "$@"; do [ -e "$_f" ] && { printf '%s' "$_f"; return 0; }; done; return 1; }
short() { printf '%s' "$1" | sed 's|.*/\([^/]*/[^/]*\)$|\1|'; }

ui_print ""
ui_print "        ⚡"
ui_print "  ╔═╗╔═╗╔═╗╔═╗"
ui_print "  ╚═╗╠═╣╠╣ ║╣ "
ui_print "  ╚═╝╩ ╩╩  ╚═╝"
ui_print "  ╔═╗╦ ╦╔═╗╦═╗╔═╗╔═╗"
ui_print "  ║  ╠═╣╠═╣╠╦╝║ ╦║╣ "
ui_print "  ╚═╝╩ ╩╩ ╩╩╚═╚═╝╚═╝"
ui_print "  ──────────────────────────"
ui_print "   Guard v$VER · by Elliowz"
ui_print "   Thermal · Limit · Fast Charge"
ui_print "  ──────────────────────────"

step 1 "Checking environment"
if [ "$KSU" = true ]; then ROOT="KernelSU $KSU_VER ($KSU_VER_CODE)"
elif [ "$APATCH" = true ]; then ROOT="APatch $APATCH_VER"
else ROOT="Magisk $MAGISK_VER ($MAGISK_VER_CODE)"; fi
[ "${API:-0}" -ge 26 ] || abort "   ✘ Requires Android 8.0+ (API 26)"
ok "Root     : $ROOT"
ok "Android  : API $API · $ARCH"

step 2 "Scanning battery"
BATT=""
for _p in "$PS"/*; do
    [ -r "$_p/type" ] || continue
    rd "$_p/type"; [ "$_v" = "Battery" ] || continue
    BATT=$_p; break
done
if [ -z "$BATT" ]; then
    no "Battery power supply not readable"
    info "Continuing install, nodes can be set manually in the WebUI"
else
    rd "$BATT/temp"; T=$_v; rd "$BATT/capacity"; C=$_v; rd "$BATT/status"; S=$_v
    ok "Battery  : ${C:-?}% · ${S:-?}"
    case "$T" in ''|*[!0-9]*) ;; *) ok "Temp     : $((T / 10)).$((T % 10)) °C" ;; esac
fi

step 3 "Detecting control nodes"
FOUND=0
CTL=$(first "$BATT/charging_enabled" "$BATT/battery_charging_enabled" "$BATT/input_suspend")
CUR=$(first "$BATT/constant_charge_current_max" "$PS/main/constant_charge_current_max")
INP=$(first "$PS/usb/input_current_limit" "$BATT/input_current_limit")
if [ -n "$CTL" ]; then ok "Control  : $(short "$CTL")"; FOUND=$((FOUND + 1)); else no "Control  : not found"; fi
if [ -n "$CUR" ]; then ok "Batt cur : $(short "$CUR")"; FOUND=$((FOUND + 1)); else no "Batt cur : not found"; fi
if [ -n "$INP" ]; then ok "Input cur: $(short "$INP")"; FOUND=$((FOUND + 1)); else no "Input cur: not found"; fi

step 4 "Installing module"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
ok "Service  : service.sh"
[ -f "$MODPATH/webroot/index.html" ] && ok "WebUI    : ready"
if [ -f "$DATA/settings.conf" ]; then ok "Config   : existing settings kept"
else ok "Config   : defaults created on boot"; fi

step 5 "Done"
ui_print "  ──────────────────────────"
ui_print "   Features ready:"
[ -n "$CTL" ] && info "Thermal cutoff & charge limit" || info "Monitor only (no control node)"
[ -n "$CUR" ] && info "Force fast charging (current)" || info "Force fast charging: set node manually"
ui_print "  ──────────────────────────"
ui_print "   Open WebUI: Modules › SafeCharge Guard"
ui_print "   Reboot to activate ⚡"
ui_print ""
