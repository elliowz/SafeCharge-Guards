#!/system/bin/sh
rm -rf /data/adb/safecharge_guard
