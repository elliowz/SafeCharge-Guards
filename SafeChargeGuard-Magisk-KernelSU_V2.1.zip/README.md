# SafeCharge Guard 2.0

Magisk/KernelSU module: thermal protection, charge limit and **forced fast charging** (current limit), with a KernelSU WebUI.

## Features (all set from the WebUI, applied instantly, no reboot)

- **Force fast charging**: writes a target current (mA, max 10,000) to `constant_charge_current_max`, plus an optional input current limit. Re-applied every 5 seconds because the kernel/thermal HAL often resets it. A value below the stock current works as a current cap. Estimated power (W) is shown in the UI.
- **Charge limit**: stop at X%, resume after dropping Y%.
- **Thermal protection**: cutoff (max 45 °C) with hysteresis, plus a current throttle at a lower temperature.
- **Advanced**: check interval, auto-detect nodes, manual node paths (must be under `/sys/class/power_supply/`) and on/off value polarity.

Settings live in `/data/adb/safecharge_guard/settings.conf` (kept across module updates). The file is never sourced; only whitelisted keys with validated values are accepted.

## Honest limits

- The module only changes the limits the kernel allows. Real charging speed is decided by the charger, cable, PMIC and OEM protection (JEITA/thermal), which are **not** disabled. If a node is missing, not writable or reset by firmware, the current will not go up.
- Nodes tried automatically: `charging_enabled`, `battery_charging_enabled`, `input_suspend`, `constant_charge_current_max`, `input_current_limit`. Nodes outside `/sys/class/power_supply/` (e.g. `/sys/class/qcom-battery`) are not supported.
- Cutoff and the % limit only work if a charging control node is found; otherwise the module just monitors.
- Original node values are saved and restored when a feature is turned off or the service stops.
- High current means high heat. Use the thermal throttle. Test on your device first and know how to disable the module from recovery.

## Install

Flash the zip from the Modules page and reboot. The WebUI is KernelSU only. Logs: `logcat -s SafeChargeGuard`.
