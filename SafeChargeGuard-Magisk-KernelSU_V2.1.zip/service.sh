#!/system/bin/sh
# SafeCharge Guard 2.0 - Magisk / KernelSU late_start service
PS=${SC_PS:-/sys/class/power_supply}
DATA=${SC_DATA:-/data/adb/safecharge_guard}
MINTICK=${SC_MIN_TICK:-5}
CONF="$DATA/settings.conf"; STATUS="$DATA/status"; PIDF="$DATA/service.pid"; STAMP="$DATA/.loaded"
TAG=SafeChargeGuard; HARD_MA=10000; HARD_T=45
KEYS="GUARD_ENABLED MAX_TEMP_C HYSTERESIS_C THROTTLE_TEMP_C THROTTLE_CURRENT_MA CHARGE_LIMIT_ENABLED CHARGE_LIMIT_PCT CHARGE_RESUME_GAP FORCE_FAST FAST_CURRENT_MA FAST_INPUT_MA CHECK_INTERVAL AUTO_DETECT CTRL_PATH CTRL_EN CTRL_DIS CURRENT_PATH INPUT_PATH"

mkdir -p "$DATA" 2>/dev/null
printf '%s\n' "$$" > "$PIDF"
note() { log -t "$TAG" "$*" 2>/dev/null; }
rd() { _v=""; [ -r "$1" ] && read -r _v < "$1"; }
num_in() { case "$1" in ''|*[!0-9]*) return 1;; esac; [ "$1" -ge "$2" ] && [ "$1" -le "$3" ]; }
safe_path() {
    [ -z "$1" ] && return 0
    case "$1" in "$PS"/*) ;; *) return 1;; esac
    case "$1" in *..*|*[!A-Za-z0-9_./-]*) return 1;; esac
    return 0
}

set_defaults() {
    GUARD_ENABLED=1; MAX_TEMP_C=42; HYSTERESIS_C=2; THROTTLE_TEMP_C=0; THROTTLE_CURRENT_MA=1500
    CHARGE_LIMIT_ENABLED=0; CHARGE_LIMIT_PCT=80; CHARGE_RESUME_GAP=5
    FORCE_FAST=0; FAST_CURRENT_MA=3000; FAST_INPUT_MA=0
    CHECK_INTERVAL=30; AUTO_DETECT=1
    CTRL_PATH=""; CTRL_EN=1; CTRL_DIS=0; CURRENT_PATH=""; INPUT_PATH=""
}
dump_conf() { for k in $KEYS; do eval "printf '%s=%s\\n' $k \"\$$k\""; done; }

# Only whitelisted keys with validated values are accepted; the file is never sourced.
load_conf() {
    set_defaults
    if [ -r "$CONF" ]; then
        while IFS='=' read -r k v || [ -n "$k" ]; do
            case "$k" in
                GUARD_ENABLED) num_in "$v" 0 1 && GUARD_ENABLED=$v ;;
                MAX_TEMP_C) num_in "$v" 30 $HARD_T && MAX_TEMP_C=$v ;;
                HYSTERESIS_C) num_in "$v" 1 10 && HYSTERESIS_C=$v ;;
                THROTTLE_TEMP_C) num_in "$v" 0 44 && THROTTLE_TEMP_C=$v ;;
                THROTTLE_CURRENT_MA) num_in "$v" 300 $HARD_MA && THROTTLE_CURRENT_MA=$v ;;
                CHARGE_LIMIT_ENABLED) num_in "$v" 0 1 && CHARGE_LIMIT_ENABLED=$v ;;
                CHARGE_LIMIT_PCT) num_in "$v" 40 100 && CHARGE_LIMIT_PCT=$v ;;
                CHARGE_RESUME_GAP) num_in "$v" 1 30 && CHARGE_RESUME_GAP=$v ;;
                FORCE_FAST) num_in "$v" 0 1 && FORCE_FAST=$v ;;
                FAST_CURRENT_MA) num_in "$v" 500 $HARD_MA && FAST_CURRENT_MA=$v ;;
                FAST_INPUT_MA) num_in "$v" 0 $HARD_MA && FAST_INPUT_MA=$v ;;
                CHECK_INTERVAL) num_in "$v" 5 300 && CHECK_INTERVAL=$v ;;
                AUTO_DETECT) num_in "$v" 0 1 && AUTO_DETECT=$v ;;
                CTRL_EN) num_in "$v" 0 1 && CTRL_EN=$v ;;
                CTRL_DIS) num_in "$v" 0 1 && CTRL_DIS=$v ;;
                CTRL_PATH) safe_path "$v" && CTRL_PATH=$v ;;
                CURRENT_PATH) safe_path "$v" && CURRENT_PATH=$v ;;
                INPUT_PATH) safe_path "$v" && INPUT_PATH=$v ;;
            esac
        done < "$CONF"
    fi
    if [ "$THROTTLE_TEMP_C" -ge "$MAX_TEMP_C" ]; then THROTTLE_TEMP_C=0; fi
    case "$CTRL_EN:$CTRL_DIS" in 0:1|1:0) ;; *) CTRL_PATH="" ;; esac
    touch "$STAMP"
}

find_batt() {
    BATT=""
    for _p in "$PS"/*; do
        [ -r "$_p/type" ] || continue
        rd "$_p/type"; [ "$_v" = "Battery" ] || continue
        BATT=$_p; break
    done
}

set_charging() { # 1 enable, 0 disable
    [ -n "$CTL" ] || return 1
    if [ "$1" = 1 ]; then _sv=$CTL_EN; else _sv=$CTL_DIS; fi
    rd "$CTL"; [ "$_v" = "$_sv" ] && return 0
    printf '%s' "$_sv" > "$CTL" 2>/dev/null
}

restore_slot() {
    eval "_n=\$${1}_NODE; _o=\$${1}_ORIG"
    if [ -n "$_n" ]; then printf '%s' "$_o" > "$_n" 2>/dev/null; note "restored $_n"; fi
    eval "${1}_NODE=''; ${1}_ORIG=''; ${1}_MA=0"
}
restore_all() {
    restore_slot CUR; restore_slot INP
    if [ "$CUT" = 1 ]; then set_charging 1; CUT=0; fi
}

# apply_ma SLOT PATH MA: writes a current limit, remembering the original value for restore.
apply_ma() {
    _s=$1; _p=$2; _m=$3
    eval "_b=\$${_s}_BAD"; [ "$_b" = "$_p" ] && return 1
    eval "_n=\$${_s}_NODE"
    if [ "$_n" != "$_p" ]; then
        restore_slot "$_s"
        rd "$_p"
        case "$_v" in ''|*[!0-9]*) eval "${_s}_BAD=\$_p"; note "cannot read $_p"; return 1;; esac
        eval "${_s}_NODE=\$_p; ${_s}_ORIG=\$_v"
    fi
    eval "_o=\$${_s}_ORIG"
    _u=1000; if [ "$_o" -gt 0 ] && [ "$_o" -lt 100000 ]; then _u=1; fi   # uA nodes vs mA nodes
    [ "$_m" -gt "$HARD_MA" ] && _m=$HARD_MA
    _w=$((_m * _u))
    rd "$_p"
    if [ "$_v" != "$_w" ] && ! printf '%s' "$_w" > "$_p" 2>/dev/null; then
        eval "${_s}_BAD=\$_p"; note "write failed: $_p"; return 1
    fi
    eval "${_s}_MA=$_m"
}

resolve_nodes() {
    restore_all
    CUR_BAD=""; INP_BAD=""; CTL=""; CTL_EN=1; CTL_DIS=0; CUR=$CURRENT_PATH; INP=$INPUT_PATH
    if [ -n "$CTRL_PATH" ]; then
        [ -e "$CTRL_PATH" ] && { CTL=$CTRL_PATH; CTL_EN=$CTRL_EN; CTL_DIS=$CTRL_DIS; }
    elif [ "$AUTO_DETECT" = 1 ]; then
        for _c in "$BATT/charging_enabled:1:0" "$BATT/battery_charging_enabled:1:0" "$BATT/input_suspend:0:1"; do
            _p=${_c%%:*}; [ -e "$_p" ] || continue
            _r=${_c#*:}; CTL=$_p; CTL_EN=${_r%%:*}; CTL_DIS=${_r#*:}; break
        done
    fi
    if [ "$AUTO_DETECT" = 1 ]; then
        if [ -z "$CUR" ]; then
            for _p in "$BATT/constant_charge_current_max" "$PS/main/constant_charge_current_max"; do
                [ -e "$_p" ] && { CUR=$_p; break; }
            done
        fi
        if [ -z "$INP" ]; then
            for _p in "$PS/usb/input_current_limit" "$BATT/input_current_limit"; do
                [ -e "$_p" ] && { INP=$_p; break; }
            done
        fi
    fi
    [ -e "$CUR" ] || CUR=""
    [ -e "$INP" ] || INP=""
    note "nodes: ctl=${CTL:-none} cur=${CUR:-none} inp=${INP:-none}"
}

write_status() {
    _m=normal
    [ "$THROTTLED" = 1 ] && _m=throttled
    [ "$LIMIT_CUT" = 1 ] && _m=limit-hold
    [ "$THERMAL_CUT" = 1 ] && _m=thermal-cut
    _s=$(printf 'st_mode=%s\nst_ctl=%s\nst_cur=%s\nst_inp=%s\nst_cur_ma=%s\n' "$_m" "${CTL:-none}" "${CUR:-none}" "${INP:-none}" "$CUR_MA")
    if [ "$_s" != "$LAST_ST" ]; then
        printf '%s\n' "$_s" > "$STATUS.tmp" && mv "$STATUS.tmp" "$STATUS"
        LAST_ST=$_s
    fi
}

CUT=0; THERMAL_CUT=0; LIMIT_CUT=0; THROTTLED=0; LAST_ST=""; RELOAD=1; CTL=""; CUR=""; INP=""
CUR_NODE=""; CUR_ORIG=""; CUR_MA=0; CUR_BAD=""; INP_NODE=""; INP_ORIG=""; INP_MA=0; INP_BAD=""
trap 'RELOAD=1' USR1
trap 'restore_all; rm -f "$PIDF"; exit 0' TERM INT HUP

set_defaults
[ -r "$CONF" ] || { dump_conf > "$CONF"; }
find_batt
note "started; battery=${BATT:-none}"

while true; do
    [ -n "$BATT" ] || find_batt
    if [ "$RELOAD" = 1 ] || [ ! -e "$STAMP" ] || [ "$CONF" -nt "$STAMP" ]; then
        RELOAD=0; load_conf; resolve_nodes
    fi
    rd "$BATT/temp"; TEMP_RAW=$_v
    rd "$BATT/capacity"; CAP=$_v
    rd "$BATT/status"; BSTATUS=$_v

    # --- thermal guard: cutoff + optional current throttle (with hysteresis) ---
    if [ "$GUARD_ENABLED" != 1 ]; then
        THERMAL_CUT=0; THROTTLED=0
    else
        case "$TEMP_RAW" in
            ''|*[!0-9]*) ;;
            *)
                if [ "$TEMP_RAW" -ge 10000 ]; then T=$((TEMP_RAW / 1000)); else T=$((TEMP_RAW / 10)); fi
                if [ "$T" -ge "$MAX_TEMP_C" ]; then THERMAL_CUT=1
                elif [ "$THERMAL_CUT" = 1 ] && [ "$T" -le $((MAX_TEMP_C - HYSTERESIS_C)) ]; then THERMAL_CUT=0; fi
                if [ "$THROTTLE_TEMP_C" -gt 0 ]; then
                    if [ "$T" -ge "$THROTTLE_TEMP_C" ]; then THROTTLED=1
                    elif [ "$THROTTLED" = 1 ] && [ "$T" -le $((THROTTLE_TEMP_C - HYSTERESIS_C)) ]; then THROTTLED=0; fi
                else THROTTLED=0; fi
                ;;
        esac
    fi

    # --- charge limit (stop at X%, resume at X% - gap) ---
    if [ "$CHARGE_LIMIT_ENABLED" != 1 ]; then
        LIMIT_CUT=0
    else
        case "$CAP" in
            ''|*[!0-9]*) ;;
            *)
                if [ "$CAP" -ge "$CHARGE_LIMIT_PCT" ]; then LIMIT_CUT=1
                elif [ "$LIMIT_CUT" = 1 ] && [ "$CAP" -le $((CHARGE_LIMIT_PCT - CHARGE_RESUME_GAP)) ]; then LIMIT_CUT=0; fi
                ;;
        esac
    fi

    # --- charging on/off (needs a verified control node) ---
    WANT=1
    [ "$THERMAL_CUT" = 1 ] && WANT=0
    [ "$LIMIT_CUT" = 1 ] && WANT=0
    if [ -n "$CTL" ]; then
        if [ "$WANT" = 0 ]; then
            if set_charging 0; then
                [ "$CUT" = 0 ] && note "charging disabled (thermal=$THERMAL_CUT limit=$LIMIT_CUT temp=${T:-?}C cap=${CAP:-?}%)"
                CUT=1
            else note "control write failed; monitor-only"; CTL=""; fi
        elif [ "$CUT" = 1 ]; then
            if set_charging 1; then CUT=0; note "charging re-enabled"; fi
        fi
    elif [ "$WANT" = 0 ] && [ "$LAST_NOCTL" != 1 ]; then
        note "limit reached but no control node; monitor-only"; LAST_NOCTL=1
    fi
    [ "$WANT" = 1 ] && LAST_NOCTL=0

    # --- current limit: forced fast charging target, lowered while throttled ---
    TARGET=0
    [ "$FORCE_FAST" = 1 ] && TARGET=$FAST_CURRENT_MA
    if [ "$THROTTLED" = 1 ] && { [ "$TARGET" -eq 0 ] || [ "$THROTTLE_CURRENT_MA" -lt "$TARGET" ]; }; then TARGET=$THROTTLE_CURRENT_MA; fi
    if [ "$TARGET" -gt 0 ] && [ -n "$CUR" ]; then
        [ "$BSTATUS" != "Discharging" ] && apply_ma CUR "$CUR" "$TARGET"
    else restore_slot CUR; fi
    if [ "$FORCE_FAST" = 1 ] && [ "$FAST_INPUT_MA" -gt 0 ] && [ "$THROTTLED" != 1 ] && [ -n "$INP" ]; then
        [ "$BSTATUS" != "Discharging" ] && apply_ma INP "$INP" "$FAST_INPUT_MA"
    else restore_slot INP; fi

    write_status
    TICK=$CHECK_INTERVAL
    if [ "$FORCE_FAST" = 1 ] || [ "$THROTTLED" = 1 ]; then TICK=$MINTICK; fi
    [ "$TICK" -lt "$MINTICK" ] && TICK=$MINTICK
    sleep "$TICK" &
    SLP=$!
    wait "$SLP"
    kill "$SLP" 2>/dev/null
done
